<?php

class Faculty_Dashboard extends MY_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model(['Admin_Faculty_Management', 'Admin_Students_Management']);
	}
	public function index()
	{
		if (!$this->session->has_userdata('fa_is_signed') && $this->session->fa_is_signed != TRUE) {
			redirect('/');
		}
		
		$data = [
		'students' => $this->Admin_Students_Management->get_studs(),
		'news' => $this->Admin_Students_Management->get_news(),
		'courses' => $this->Admin_Faculty_Management->get_my_courses($this->session->fac_id),
		'grades' => $this->Admin_Faculty_Management->get_grade_status($this->session->fac_id)
		];

		$this->faculty('faculty/home', $data);
	}

	public function EncodeGrade($id, $subj_id)
	{
		$data = [
		'student' => $this->Admin_Faculty_Management->get_student_by_id($this->session->fac_id, $id, $subj_id)
		];
		$this->faculty('faculty/grade_encoder/encode_grade', $data);
	}

	public function EncodeGrade_Submitted()
	{
		$data = [
			'grade' => $this->input->post('grade'),
			'graded_subject_id' => $this->input->post('subject_id'),
			'fac_id' => $this->session->fac_id,
			'graded_student_id' => $this->input->post('student_id'),
			'grade_type' => $this->input->post('grade_type'),
		];

		$this->Admin_Faculty_Management->insert_grade($data);
		return redirect('Faculty/Dashboard');
	}

	public function Manual()
	{
		$this->admin_inside('admin/manual', null);
	}
	public function Changelogs()
	{
		$this->admin_inside('admin/changelogs', null);
	}
}