<?php
class AssignersClass extends MY_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model(['Admin_Students_Management', 'Admin_Faculty_Management']);
	}

	public function add_class()
	{

	}

	public function edit_class()
	{

	}

	public function show_classes()
	{

	}

	public function add_course()
	{

	}

	public function edit_course()
	{

	}

	public function show_courses()
	{

	}	

}